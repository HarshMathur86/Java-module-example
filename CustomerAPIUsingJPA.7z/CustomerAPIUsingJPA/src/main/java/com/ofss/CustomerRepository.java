package com.ofss;

import org.springframework.data.repository.CrudRepository;

public interface CustomerRepository extends CrudRepository<Customers, Integer>{

}
