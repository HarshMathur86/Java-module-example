package com.ofss;

import java.util.ArrayList;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CustomerService1 {

	@Autowired
	CustomerRepository cRepository;
	
	public String addACustomer(Customers cust)
	{
		cRepository.save(cust);
		// This save method generates the required SQL QUERIES
		return "Successfully inserted";
	}
	
	public ArrayList<Customers> getAllCustomers()
	{
		System.out.println("Calling all customers from CustomerService1 JPA");
		ArrayList<Customers> allCustomers=new ArrayList<>();	
		cRepository.findAll().forEach(customers -> allCustomers.add(customers));	 	 	
		
		return allCustomers;
	}
	
	public String deleteById(int cid)
	{
		System.out.println("Calling delete by id from CustomerService1 JPA");
		try {
			cRepository.delete(cid);
			return "Successfull deleted";
		} catch (Exception e) {
			return "Id don't exist.";
		}
	}
	
	public String updateCustomer(int custId, Customers cust) {
		System.out.println("Updating customer using Customer Repository "+custId);
		Customers customer = cRepository.findOne(custId);
		if(cust.getPhoneNumber() != 0) customer.setPhoneNumber(cust.getPhoneNumber());
		if(cust.getCustomerId() != 0) customer.setCustomerId(cust.getCustomerId());
		if(cust.getFirstName() != null) customer.setFirstName(cust.getFirstName());
		if(cust.getLastName() != null) customer.setLastName(cust.getLastName());
		if(cust.getEmail() != null) customer.setEmail(cust.getEmail());
		
		cRepository.save(customer);
		return "Updated";
	}


}
