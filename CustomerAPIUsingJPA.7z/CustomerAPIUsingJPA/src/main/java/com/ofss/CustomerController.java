package com.ofss;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController	
public class CustomerController {

	@Autowired
	CustomerService1 cs;
	
	//@RequestMapping(value="/customers",method=RequestMethod.GET)
	@RequestMapping(value="/customers",method=RequestMethod.GET, produces="application/json")
	public ArrayList<Customers> getAllCustomers()
	{
		System.out.println("Customer controller");		
		return cs.getAllCustomers();
	}
	
	@RequestMapping(value="/customers",method=RequestMethod.POST)
	public String addCustomer(@RequestBody Customers newCustomer	)
	{
		return cs.addACustomer(newCustomer);
	}
	
	@RequestMapping(value="/customer/id/{id}",method=RequestMethod.DELETE)
	public String removeCustomer(@PathVariable("id") int cid)
	{
		System.out.println("The id received is "+cid);
		return cs.deleteById(cid);
	}

	@RequestMapping(value="/customer/phonenumber/{pn}",method=RequestMethod.DELETE)
	public String removeACustomer(@PathVariable("pn") long pnumber)
	{
		System.out.println("The phone number received is "+pnumber);
		return "dummy";
		
	}

	@RequestMapping(value="/customer/id/{id}",method=RequestMethod.GET)
	public Customers getMeOneCustomer(@PathVariable("id") int cid)
	{
		System.out.println("The id entered by the user is "+cid);
		return null;
	}
	
	
	@RequestMapping(value="/customer/id/{id}",method=RequestMethod.PUT)
	public String updateACustomerCompletely(@PathVariable("id") int cid, @RequestBody Customers updateCustomer) {
		System.out.println("Update id received is "+cid);
		return "dummy";
	}
	
	@RequestMapping(value="/customer/id/{id}",method=RequestMethod.PATCH)
	public String updateACustomer(@PathVariable("id") int cid, @RequestBody Customers updateCustomer) {
		System.out.println("Update id received is "+cid);
		return cs.updateCustomer(cid, updateCustomer);
	}
}
