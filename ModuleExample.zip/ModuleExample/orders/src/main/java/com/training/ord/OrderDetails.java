package com.training.ord;

import com.traning.rev.Reviews;

public class OrderDetails {
	public static void main(String[] args) {
		System.out.println(Reviews.getReviews(12121));
	}
}
