package com.traning.rev;

public class Reviews {

	public Reviews() {
	}
	
	public static String getReviews(int productId) {
		return "Reviews for: " + productId + " is very good product(4.5+)";
	}
}
