module reviews {
	exports com.traning.rev;
}